#ifndef _SEARCH_HEADER
#define _SEARCH_HEADER
/*
    Pre-condition: 
        N is the size of A
    Post-condition:
        return P if A[P] = x; return -1 otherwise

*/


extern int search(int x, int A[], int N);
#endif
