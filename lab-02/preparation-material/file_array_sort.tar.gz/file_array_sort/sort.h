#ifndef SORT_H
#define SORT_H
void sort(int arr[], int n);
#endif