echo "Enter pattern:"
read s
ls -R $s
